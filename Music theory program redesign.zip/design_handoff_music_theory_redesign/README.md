# Handoff: Music Theory Trainer — Cream Redesign

## Overview
A visual redesign of the existing music theory training site (github.com/boris-volkov/music, `main` @ `f3ff9cc597f6`). The goal was to replace the muted blue-grey palette and cramped layout with the warm retro-computer "cream" aesthetic used in the LMC project (github.com/boris-volkov/LMC), fix the over-wide piano keys, and reorganize the options menu into grouped panels instead of one long list.

Functionality is unchanged. Only the layout, palette, typography, and keyboard proportions are new.

## About the Design Files
`Music Theory Redesign.dc.html` in this bundle is a **design reference created in HTML** — a static prototype showing the intended look, proportions, and structure. It is not production code to copy directly, and it contains no MIDI, quiz, or audio logic.

The task is to **apply this design to the existing `boris-volkov/music` codebase**, which is vanilla HTML + CSS + JS with no build step. In practice that means rewriting `style.css` and restructuring `index.html`, while leaving the existing quiz/MIDI/theory scripts (`midi.js`, `theory.js`, `*_quiz.js`, `buttons.js`, etc.) wired to the same element IDs they use today.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and key proportions are final and should be matched exactly. The interaction states (hover, active, correct-note flash) are specified below but were not all built into the prototype.

## Screens / Views

### Single view: Practice screen

**Page shell**
- Background `#f0ead8`, `padding: 20px`, `min-height: 100vh`
- Flex column, `gap: 20px`
- Font stack: `'IBM Plex Sans', sans-serif`; body text color `#2a2520`

**Header**
- Flex row, `align-items: baseline`, `gap: 8px`
- `padding-bottom: 12px`, `border-bottom: 2px solid #d4c5aa`
- Title "Music Theory": 28px / 700 / `letter-spacing: 0.02em` / `#2a2520`
- Kicker "PRACTICE": 14px / 500 / `letter-spacing: 0.05em` / `#7a6f5d`

**Body grid**
- `display: grid; grid-template-columns: 1fr 2fr; gap: 24px; max-width: 1400px; margin: 0 auto`
- Left column = controls, right column = display + keyboard

### Left column

**Instruction block**
- Background `#2a2520`, text `#f0ead8`, `padding: 16px`, `border-radius: 8px`
- `'IBM Plex Mono'`, 13px, `line-height: 1.6`, each line `opacity: 0.8`, `margin-bottom: 8px`
- Copy: `→ Select a topic below` / `→ Play the shown notes` / `→ Keys light green when correct`

**Menu panels** (three of them: "Base Notes", "Intervals", "Chords & Scales")
- Card: background `#fff8ef`, `border: 2px solid #d4c5aa`, `border-radius: 8px`
- Header row: `padding: 12px 16px`, `border-bottom: 2px solid #d4c5aa`, 12px / 600 / uppercase / `letter-spacing: 0.06em` / `#7a6f5d`
- Body: flex column, `gap: 6px`, `padding: 12px`
- Buttons: `padding: 8px 12px`, `border-radius: 5px`, 13px / 500, `transition: background 0.15s`
  - Base Notes buttons — teal: background `#b8d4c8`, border `1px solid #9ec4b4`
  - Interval + Chord/Scale buttons — clay: background `#e8b5a0`, border `1px solid #d4a085`
- Button labels as built: Notes · Sharps & Flats | Listen & Identify · Play from Description | Chord Recognition · Scale Degrees · Modes

**More options button**
- `margin-top: auto` (pins to bottom of column), `padding: 12px 16px`
- Background `#2a2520`, text `#f0ead8`, no border, `border-radius: 6px`
- 13px / 600 / `letter-spacing: 0.05em`
- Label `⚙ MORE OPTIONS` — opens the fuller option set (the checkbox lists from the current site)

### Right column

**Display panel** (replaces the current `<pre id="terminal">`)
- Background `#2a2520`, text `#f0ead8`, `padding: 20px`, `border-radius: 8px`, `min-height: 120px`
- Centered, `'IBM Plex Mono'`, `line-height: 1.6`
- Status line: 12px, `opacity: 0.6`, `letter-spacing: 0.1em`, `margin-bottom: 8px` — e.g. `WAITING FOR INPUT`
- Prompt line: 24px / 700 / `letter-spacing: 0.05em` — e.g. `C4`

**Piano keyboard**
- Outer: `position: relative`, background `#fff8ef`, `border: 2px solid #d4c5aa`, `border-radius: 8px`, `padding: 12px`

- White keys: flex row, `gap: 3px`, `z-index: 1`
  - Each: `flex: 1`, `min-height: 280px`, background `#e8dcc8`, `border: 2px solid #d4c5aa`, `border-radius: 0 0 8px 8px`
  - Label at bottom (`align-items: flex-end`, `padding-bottom: 8px`): 12px / 600 / `#7a6f5d`

- Black keys: absolutely positioned overlay, `top: 12px; left: 12px; right: 12px; height: 178px; z-index: 2; pointer-events: none` (each key sets `pointer-events: auto`)
  - Each: `width: 8.5%`, `height: 100%`, background `#2a2520`, `border: 2px solid #1a1510`, `border-radius: 0 0 5px 5px`
  - Left offsets: `10.04%`, `24.32%`, `52.89%`, `67.18%`, `81.46%`

  **Proportions — this was the main fix.** Seven white keys means each boundary sits at `n/7`. A black key is 8.5% of the keyboard width (≈60% of a white key) and is centered on its boundary, so `left = (n/7 × 100%) − 4.25%`. Black key height is ~63% of white key height. Do not reintroduce fixed `vw` widths — that is what made the original keys grow to full-screen width.

**Feedback line**
- `height: 40px`, centered, `'IBM Plex Mono'`, 14px / 600
- Correct-state color `#a0d6b8`

## Interactions & Behavior
- **Topic buttons** — clicking selects a practice mode; the active button should read as selected (use the existing `.active` class hook). Suggested active treatment: background `#2a2520`, text `#f0ead8`.
- **Button hover** — lighten the fill; `transition: background 0.15s` is already specified.
- **Key press (mouse/touch)** — white key darkens to `#d4c5aa`, black key to `#1a1510`, released on mouseup/touchend.
- **Correct answer** — the target keys flash green. A `greenFlash` keyframe is defined in the prototype (`#b8d4c8` → `#a0d6b8` → `#b8d4c8`); the current site turns keys green directly, either is fine.
- **MIDI input** — unchanged; keeps lighting keys by note index as it does now.
- **More options** — toggles the detailed option panel. In the current site this is the `#options_toggle` `[*]` button showing/hiding `#choices`.
- **Responsive** — below ~900px the two-column grid should stack to one column, keyboard full width. Not built in the prototype.

## State Management
No new state. The existing globals carry over:
- active practice mode / selected quiz
- current prompt (note, interval, chord, or scale being asked)
- set of currently-held MIDI notes
- per-quiz option selections (which intervals, chords, scales are in the pool)
- correct/incorrect feedback state driving the green flash

## Design Tokens

Colors
| Token | Hex | Use |
|---|---|---|
| canvas | `#f0ead8` | page background |
| panel | `#fff8ef` | card / keyboard background |
| line | `#d4c5aa` | borders, rules |
| ink | `#2a2520` | text, black keys, dark panels |
| ink deep | `#1a1510` | black key border |
| ink soft | `#7a6f5d` | secondary text, panel headers, key labels |
| white key | `#e8dcc8` | white key fill |
| white key pressed | `#d4c5aa` | white key active |
| teal | `#b8d4c8` | primary topic buttons |
| teal border | `#9ec4b4` | primary button border |
| teal bright | `#a0d6b8` | correct-answer flash, success text |
| clay | `#e8b5a0` | secondary topic buttons |
| clay border | `#d4a085` | secondary button border |

Spacing: 3 · 6 · 8 · 12 · 16 · 20 · 24 px

Typography
- `'IBM Plex Sans'` 400/500/600/700 — UI
- `'IBM Plex Mono'` 400/500/600/700 — display, instructions, feedback
- Sizes: 12 · 13 · 14 · 16 · 24 · 28 px
- Google Fonts: `https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap`

Radii: 5px (black keys, small buttons) · 6px (dark buttons) · 8px (cards, white keys, panels)

Borders: 1px (buttons) · 2px (cards, keys, rules)

Shadows: none — the design is flat, depth comes from borders and fill contrast.

## Assets
None. No images, icons, or SVGs — the only glyph is the `⚙` character in the More Options label.

## Files
- `Music Theory Redesign.dc.html` — the design reference (self-contained, opens in a browser)
- Source repo: `boris-volkov/music`, branch `main`, commit `f3ff9cc597f6`
  - `index.html` — structure to restyle; keep existing element IDs so the scripts keep working
  - `style.css` — to be replaced wholesale by the tokens above
  - `buttons.js` — builds the option buttons; will need updating for the grouped panel markup
  - `midi.js`, `theory.js`, `terminal.js`, `note_quiz.js`, `interval_quiz.js`, `chord_quiz.js`, `scale_quiz.js`, `scale_degrees.js`, `interval_ear_training.js` — logic, no changes expected

## Notes for implementation
- Preserve the numeric key IDs (`0`–`11`) and the `.white` / `.black` class names — `midi.js` targets them directly.
- The old `#terminal` `<pre>` becomes the dark display panel; keep the ID if that is where text is written.
- The old inline `[*]` `[~]` `[±]` button row is replaced by the single More Options button; fullscreen and color-cycle can move into the options panel or be dropped.
